/// <reference types="vite/client" />\n\ndeclare const __SUPABASE_URL__: string;\ndeclare const __SUPABASE_ANON_KEY__: string;
